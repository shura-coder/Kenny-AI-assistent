import requests

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

def ask_llm(prompt):
    response = requests.post(
        OLLAMA_URL,
        json={
            "model": "qwen3:8b",
            "prompt": prompt,
            "stream": False
        }
    )

    return response.json()["response"]