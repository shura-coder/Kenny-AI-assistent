import requests

def get_web_page(url):
    try:
        r = requests.get(url, timeout=10)
        return r.text[:5000]
    except Exception as e:
        return str(e)