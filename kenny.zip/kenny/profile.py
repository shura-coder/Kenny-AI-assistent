import json
import os

FILE = "profile.json"


def load_profile():

    if not os.path.exists(FILE):
        return {
            "name": "",
            "facts": [],
            "likes": []
        }

    with open(FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_profile(profile):

    with open(FILE, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=4)