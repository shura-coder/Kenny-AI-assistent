import json
import os

FILE = "memory.json"

def load_memory():
    if not os.path.exists(FILE):
        return {"events": []}

    with open(FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_memory(memory):
    with open(FILE, "w", encoding="utf-8") as f:
        json.dump(memory, f, ensure_ascii=False, indent=4)

def add_event(memory, text):
    memory["events"].append(text)
    save_memory(memory)