import json

FILE = "personality.json"


def load_personality():

    with open(FILE, "r", encoding="utf-8") as f:
        return json.load(f)