import json

FILE = "goals.json"


def load_goals():

    with open(FILE, "r", encoding="utf-8") as f:
        return json.load(f)