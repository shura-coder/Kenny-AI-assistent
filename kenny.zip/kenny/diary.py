import json
from datetime import datetime

FILE = "diary.json"


def add_diary_entry(text):

    with open(FILE, "r", encoding="utf-8") as f:
        diary = json.load(f)

    diary["entries"].append({
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "text": text
    })

    with open(FILE, "w", encoding="utf-8") as f:
        json.dump(diary, f, ensure_ascii=False, indent=4)