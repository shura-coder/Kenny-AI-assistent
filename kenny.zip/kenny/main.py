from memory import load_memory, add_event
from profile import load_profile
from goals import load_goals
from personality import load_personality
from brain import chat

print("🧬 Kenny v2 запущен.")
print("Напиши 'выход' для завершения.\n")

memory = load_memory()
profile = load_profile()
goals = load_goals()
personality = load_personality()

while True:

    user = input("Ты: ")

    if user.lower() in ["выход", "exit", "quit"]:
        print("Кенни: До встречи.")
        break

    answer = chat(
        user_message=user,
        memory=memory,
        profile=profile,
        goals=goals,
        personality=personality
    )

    print(f"\nКенни: {answer}\n")

    add_event(memory, f"Пользователь: {user}")
    add_event(memory, f"Кенни: {answer}")