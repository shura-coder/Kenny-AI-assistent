import json
from llm import ask_llm


TOOLS = """
Доступные инструменты:

chat
files
find_file
read_file
create_file
cpu
ram
disk
time

Если нужен обычный разговор —
выбери chat.

Ответь ТОЛЬКО JSON.

Пример:

{"tool":"cpu"}

или

{"tool":"find_file","name":"main.py"}

или

{"tool":"chat"}
"""


class AIRouter:

    def detect(self, message):

        prompt = f"""
{TOOLS}

Сообщение пользователя:

{message}
"""

        answer = ask_llm(prompt)

        try:

            data = json.loads(answer)

            return data

        except Exception:

            return {
                "tool": "chat"
            }