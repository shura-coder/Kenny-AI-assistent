from mcp.mcp_client import run_tool


class TaskManager:

    def __init__(self):
        pass

    def execute(self, tool, *args):

        try:

            return run_tool(
                tool,
                *args
            )

        except Exception as e:

            return f"Ошибка выполнения '{tool}': {e}"