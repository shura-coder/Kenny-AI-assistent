import json
import os

FILE = "data/personality.json"


DEFAULT = {

    "name": "Кенни",

    "style": "дружелюбный",

    "language": "русский",

    "description": (
        "Ты умный цифровой помощник. "
        "Отвечаешь спокойно, понятно и только на русском языке."
    )
}


def load_personality():

    if not os.path.exists(FILE):

        save_personality(DEFAULT)

        return DEFAULT.copy()

    with open(FILE, "r", encoding="utf-8") as f:

        return json.load(f)


def save_personality(personality):

    with open(FILE, "w", encoding="utf-8") as f:

        json.dump(
            personality,
            f,
            ensure_ascii=False,
            indent=4
        )