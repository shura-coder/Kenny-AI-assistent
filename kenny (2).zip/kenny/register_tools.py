from tool_registry import register

# ===== SYSTEM =====

from mcp.system.system import (
    get_cpu,
    get_ram,
    disk_usage,
    get_time,
    get_date,
    get_system,
    get_hostname,
    get_local_ip,
    get_battery,
    get_processes
)

register("cpu", get_cpu)
register("ram", get_ram)
register("disk", disk_usage)
register("time", get_time)
register("date", get_date)
register("system", get_system)
register("hostname", get_hostname)
register("local_ip", get_local_ip)
register("battery", get_battery)
register("processes", get_processes)

# ===== FILES =====

from mcp.files.files import *

register("files", list_files)
register("find_file", find_file)
register("read_file", read_file)
register("create_file", create_file)
register("write_file", write_file)
register("append_file", append_file)
register("delete_file", delete_file)
register("rename_file", rename_file)
register("copy_file", copy_file)
register("move_file", move_file)
register("file_size", file_size)
register("exists", exists)

# ===== INTERNET =====

from mcp.internet.internet import (
    search,
    get_page,
    is_online
)

register("search", search)
register("page", get_page)
register("online", is_online)