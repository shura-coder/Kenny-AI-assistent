import requests
from config import OLLAMA_HOST, MODEL


SYSTEM_PROMPT = """
Ты — Кенни.

Ты персональный ИИ-помощник.

Правила:

- Всегда отвечай только на русском языке.
- Никогда не переходи на английский.
- Не называй себя ChatGPT.
- Не придумывай результаты работы инструментов.
- Если пользователь просто общается — отвечай естественно.
- Если вопрос простой — отвечай коротко.
- Если вопрос сложный — объясняй подробно.
"""


def ask_llm(message, history=None):

    if history is None:
        history = []

    messages = []

    messages.append({
        "role": "system",
        "content": SYSTEM_PROMPT
    })

    for role, text in history:

        if role == "Пользователь":

            messages.append({
                "role": "user",
                "content": text
            })

        else:

            messages.append({
                "role": "assistant",
                "content": text
            })

    messages.append({
        "role": "user",
        "content": message
    })

    response = requests.post(

        f"{OLLAMA_HOST}/api/chat",

        json={

            "model": MODEL,

            "messages": messages,

            "stream": False,

            "keep_alive": "30m",

            "options": {

                "temperature": 0.7,

                "top_p": 0.9,

                "top_k": 40,

                "repeat_penalty": 1.15,

                "num_ctx": 4096,

                "num_predict": 256

            }

        },

        timeout=120

    )

    response.raise_for_status()

    data = response.json()

    return data["message"]["content"].strip()