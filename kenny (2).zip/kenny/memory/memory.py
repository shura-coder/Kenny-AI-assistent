import json
import os
from datetime import datetime

MEMORY_FILE = "data/memory.json"


def load_memory():

    if not os.path.exists(MEMORY_FILE):

        return {
            "events": []
        }

    try:

        with open(MEMORY_FILE, "r", encoding="utf-8") as f:

            data = json.load(f)

        if not isinstance(data, dict):

            return {"events": []}

        if "events" not in data:

            data["events"] = []

        return data

    except:

        return {
            "events": []
        }


def save_memory(memory):

    os.makedirs("data", exist_ok=True)

    with open(MEMORY_FILE, "w", encoding="utf-8") as f:

        json.dump(
            memory,
            f,
            ensure_ascii=False,
            indent=4
        )


def add_event(memory, user_message, kenny_message):

    memory.setdefault("events", [])

    memory["events"].append({

        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),

        "user": user_message,

        "kenny": kenny_message

    })

    save_memory(memory)


def clear_memory():

    memory = {

        "events": []

    }

    save_memory(memory)

    return memory


def get_history(memory, limit=10):

    history = []

    events = memory.get("events", [])

    for event in events[-limit:]:

        if not isinstance(event, dict):
            continue

        user = event.get("user", "")
        kenny = event.get("kenny", "")

        if user:
            history.append(("Пользователь", user))

        if kenny:
            history.append(("Кенни", kenny))

    return history