import json
import os

FILE = "data/goals.json"


def load_goals():

    if not os.path.exists(FILE):

        goals = {
            "goals": []
        }

        save_goals(goals)

        return goals

    with open(FILE, "r", encoding="utf-8") as f:

        return json.load(f)


def save_goals(goals):

    with open(FILE, "w", encoding="utf-8") as f:

        json.dump(
            goals,
            f,
            ensure_ascii=False,
            indent=4
        )


def add_goal(goals, goal):

    goals["goals"].append(goal)

    save_goals(goals)