import json
import os

FILE = "data/state.json"


DEFAULT = {

    "version": "1.0",

    "thinking": False,

    "mood": "normal",

    "energy": 100
}


def load_state():

    if not os.path.exists(FILE):

        save_state(DEFAULT)

        return DEFAULT.copy()

    with open(FILE, "r", encoding="utf-8") as f:

        return json.load(f)


def save_state(state):

    with open(FILE, "w", encoding="utf-8") as f:

        json.dump(
            state,
            f,
            ensure_ascii=False,
            indent=4
        )