import json
import os

FILE = "data/diary.json"


def load_diary():

    if not os.path.exists(FILE):

        diary = {
            "notes": []
        }

        save_diary(diary)

        return diary

    with open(FILE, "r", encoding="utf-8") as f:

        return json.load(f)


def save_diary(diary):

    with open(FILE, "w", encoding="utf-8") as f:

        json.dump(
            diary,
            f,
            ensure_ascii=False,
            indent=4
        )


def add_note(diary, text):

    diary["notes"].append(text)

    save_diary(diary)