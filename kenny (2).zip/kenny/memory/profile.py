import json
import os

FILE = "data/profile.json"


def load_profile():

    if not os.path.exists(FILE):

        profile = {
            "name": "",
            "age": "",
            "city": "",
            "likes": [],
            "dislikes": []
        }

        save_profile(profile)

        return profile

    with open(FILE, "r", encoding="utf-8") as f:

        return json.load(f)


def save_profile(profile):

    with open(FILE, "w", encoding="utf-8") as f:

        json.dump(
            profile,
            f,
            ensure_ascii=False,
            indent=4
        )


def update_profile(profile, key, value):

    profile[key] = value

    save_profile(profile)


def add_like(profile, value):

    if value not in profile["likes"]:

        profile["likes"].append(value)

        save_profile(profile)


def add_dislike(profile, value):

    if value not in profile["dislikes"]:

        profile["dislikes"].append(value)

        save_profile(profile)