from brain import Brain

from memory.memory import load_memory
from memory.profile import load_profile
from memory.goals import load_goals
from memory.diary import load_diary
from memory.state import load_state
import register_tools

from personality.personality import load_personality


class Kenny:

    def __init__(self):

        print("🧠 Инициализация Kenny...")

        self.memory = load_memory()
        self.profile = load_profile()
        self.goals = load_goals()
        self.diary = load_diary()
        self.state = load_state()
        self.personality = load_personality()

        self.brain = Brain()

        print("✅ Kenny готов к работе!")

    def chat(self, message):

        self.state["thinking"] = True

        try:

            answer = self.brain.think(
                message,
                self.memory,
                self.profile,
                self.goals,
                self.personality
            )

        except Exception as e:

            answer = f"Ошибка: {e}"

        self.state["thinking"] = False

        return answer