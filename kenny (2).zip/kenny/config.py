MODEL = "qwen3:8b"

OLLAMA_HOST = "http://127.0.0.1:11434"

TAVILY_API_KEY = ""