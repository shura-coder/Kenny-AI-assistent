from kenny import Kenny
from memory.memory import add_event


def main():

    kenny = Kenny()

    print("=" * 50)
    print("🧠 Kenny AI")
    print("Введите 'выход' для завершения.")
    print("=" * 50)

    while True:

        user = input("\nТы: ").strip()

        if not user:
            continue

        if user.lower() in ["выход", "exit", "quit"]:
            print("Кенни: До встречи!")
            break

        try:

            answer = kenny.chat(user)

            print(f"\nКенни: {answer}")

            add_event(
                kenny.memory,
                user,
                answer
            )

        except KeyboardInterrupt:

            print("\nКенни: Работа остановлена.")
            break

        except Exception as e:

            print(f"\nОшибка: {e}")


if __name__ == "__main__":
    main()