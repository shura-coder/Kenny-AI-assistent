import json
from llm import ask_llm


class AIRouter:

    def route(self, message):

        prompt = f"""
Ты являешься маршрутизатором команд.

Ты должен ответить ТОЛЬКО JSON.

Доступные действия:

chat

cpu
ram
disk
time
date
system
hostname
local_ip
battery
processes

files
find_file
read_file
create_file
write_file
append_file
delete_file
rename_file
copy_file
move_file
file_size

search
page
online

Верни ответ такого вида:

{{
    "action":"cpu",
    "args":[]
}}

или

{{
    "action":"find_file",
    "args":["main.py"]
}}

или

{{
    "action":"chat",
    "args":[]
}}

Сообщение пользователя:

""" + message

        try:

            result = ask_llm(prompt)

            return json.loads(result)

        except:

            return {
                "action": "chat",
                "args": []
            }