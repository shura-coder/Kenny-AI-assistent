class EventBus:

    def __init__(self):

        self.listeners = {}

    def on(self, event, func):

        if event not in self.listeners:
            self.listeners[event] = []

        self.listeners[event].append(func)

    def emit(self, event, data=None):

        if event not in self.listeners:
            return

        for func in self.listeners[event]:
            func(data)