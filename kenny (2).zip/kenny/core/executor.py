from task_manager import TaskManager


class Executor:

    def __init__(self):

        self.tasks = TaskManager()

    def execute_plan(self, plan):

        results = []

        for step in plan:

            tool = step["tool"]

            args = step.get("args", [])

            result = self.tasks.execute(
                tool,
                *args
            )

            results.append(result)

        return results