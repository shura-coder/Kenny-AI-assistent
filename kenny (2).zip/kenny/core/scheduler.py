import threading
import time


class Scheduler:

    def __init__(self):

        self.tasks = []

        self.running = False

    def add(self, interval, func):

        self.tasks.append((interval, func))

    def start(self):

        self.running = True

        threading.Thread(
            target=self.loop,
            daemon=True
        ).start()

    def loop(self):

        timers = {}

        while self.running:

            now = time.time()

            for interval, func in self.tasks:

                last = timers.get(func, 0)

                if now - last >= interval:

                    timers[func] = now

                    try:

                        func()

                    except Exception:

                        pass

            time.sleep(1)