class ProfileReader:

    def answer(self, message, profile):

        text = message.lower()

        if "как меня зовут" in text:

            if profile["name"]:

                return f"Тебя зовут {profile['name']}."

            return "Я пока не знаю, как тебя зовут."

        if "сколько мне лет" in text:

            if profile["age"]:

                return f"Тебе {profile['age']} лет."

            return "Я пока не знаю твой возраст."

        if "что я люблю" in text:

            if len(profile["likes"]) == 0:

                return "Я пока не знаю, что тебе нравится."

            return "Тебе нравится:\n• " + "\n• ".join(profile["likes"])

        if "что я не люблю" in text:

            if len(profile["dislikes"]) == 0:

                return "Я пока не знаю, что тебе не нравится."

            return "Тебе не нравится:\n• " + "\n• ".join(profile["dislikes"])

        if "какой мой город" in text:

            if profile["city"]:

                return f"Ты живёшь в городе {profile['city']}."

            return "Я пока не знаю, где ты живёшь."

        return None