from llm import ask_llm
import json


class Planner:

    def make_plan(self, task):

        prompt = f"""
Ты планировщик задач.

Разбей задачу пользователя на последовательные шаги.

Верни только JSON.

Пример:

[
    {{
        "tool":"search",
        "args":["Python"]
    }},
    {{
        "tool":"chat",
        "args":[]
    }}
]

Задача:

{task}
"""

        try:

            answer = ask_llm(prompt)

            return json.loads(answer)

        except:

            return []