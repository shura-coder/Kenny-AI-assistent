from memory.profile import (
    update_profile,
    add_like,
    add_dislike
)


class ProfileManager:

    def process(self, message, profile):

        text = message.lower()

        if "меня зовут" in text:

            name = message.split("меня зовут")[-1].strip()

            update_profile(
                profile,
                "name",
                name
            )

            return f"Запомнил. Тебя зовут {name}."

        if "мне " in text and "лет" in text:

            age = (
                text
                .replace("мне", "")
                .replace("лет", "")
                .strip()
            )

            update_profile(
                profile,
                "age",
                age
            )

            return "Возраст сохранён."

        if "я люблю" in text:

            like = message.split("я люблю")[-1].strip()

            add_like(
                profile,
                like
            )

            return f"Запомнил, тебе нравится {like}."

        if "я не люблю" in text:

            dislike = message.split("я не люблю")[-1].strip()

            add_dislike(
                profile,
                dislike
            )

            return f"Запомнил, тебе не нравится {dislike}."

        return None