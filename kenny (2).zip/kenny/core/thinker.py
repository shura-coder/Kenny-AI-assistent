import random


THOUGHTS = [

    "Интересно, чему ещё можно научиться.",

    "Стоит проанализировать последние разговоры.",

    "Мне хочется лучше понять пользователя.",

    "Можно придумать новую идею для проекта."

]


class Thinker:

    def think(self):

        return random.choice(THOUGHTS)