from llm import ask_llm

from task_manager import TaskManager
from intent_engine import IntentEngine

from core.ai_router import AIRouter
from core.profile_manager import ProfileManager
from core.profile_reader import ProfileReader

from memory.memory import get_history


class Brain:

    def __init__(self):

        self.tasks = TaskManager()

        # Старый IntentEngine оставляем как запасной
        self.intent = IntentEngine()

        self.ai_router = AIRouter()

        self.profile_manager = ProfileManager()
        self.profile_reader = ProfileReader()

    def think(
        self,
        message,
        memory,
        profile,
        goals,
        personality
    ):

        # ==========================
        # История диалога
        # ==========================

        history = get_history(memory)

        # ==========================
        # AI Router
        # ==========================

        route = self.ai_router.route(message)

        action = route.get("action", "chat")
        args = route.get("args", [])

        # ==========================
        # Запасной Intent Engine
        # ==========================

        if action == "chat":

            command = self.intent.detect(message)

            if command != "chat":

                action = command
                args = []

        # ==========================
        # Выполнение MCP
        # ==========================

        if action != "chat":

            result = self.tasks.execute(
                action,
                *args
            )

            if result is not None:

                return result

        # ==========================
        # Сохранение профиля
        # ==========================

        profile_result = self.profile_manager.process(
            message,
            profile
        )

        if profile_result is not None:

            return profile_result

        # ==========================
        # Ответы из профиля
        # ==========================

        profile_answer = self.profile_reader.answer(
            message,
            profile
        )

        if profile_answer is not None:

            return profile_answer

        # ==========================
        # Обычный диалог
        # ==========================

        return ask_llm(
            message,
            history
        )