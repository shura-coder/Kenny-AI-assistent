TOOLS = {}


def register(name, function):
    TOOLS[name] = function


def get(name):
    return TOOLS.get(name)


def list_tools():
    return list(TOOLS.keys())