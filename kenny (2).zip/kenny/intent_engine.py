class IntentEngine:

    def __init__(self):

        self.commands = {

            "files": [
                "покажи файлы",
                "список файлов",
                "какие файлы"
            ],

            "find_file": [
                "найди файл",
                "отыщи файл",
                "найди"
            ],

            "read_file": [
                "прочитай файл",
                "открой файл"
            ],

            "create_file": [
                "создай файл"
            ],

            "cpu": [
                "процессор",
                "cpu",
                "загрузка процессора"
            ],

            "ram": [
                "оперативная память",
                "озу",
                "ram"
            ],

            "disk": [
                "свободное место",
                "место на устройстве",
                "место на диске",
                "место",
                "диск"
            ],

            "time": [
                "который час",
                "время"
            ],          

            "search": [
                "найди",
                "поищи",
                "найди в интернете",
                "поиск"
            ],

            "page": [
            "открой сайт",
            "прочитай сайт"
        ],

            "online": [
            "есть интернет",
            "проверь интернет"
        ]

        }

    def detect(self, message):

        text = message.lower()

        for command, words in self.commands.items():

            for word in words:

                if word in text:

                    return command

        return "chat"