import psutil
import platform
import socket
from datetime import datetime


# ==========================
# CPU
# ==========================

def get_cpu():

    return round(
        psutil.cpu_percent(interval=1),
        1
    )


# ==========================
# RAM
# ==========================

def get_ram():

    ram = psutil.virtual_memory()

    return {

        "percent": round(ram.percent, 1),

        "used": round(ram.used / 1024**3, 2),

        "total": round(ram.total / 1024**3, 2)

    }


# ==========================
# Disk
# ==========================

def disk_usage(path="C:/"):

    disk = psutil.disk_usage(path)

    return {

        "total": round(disk.total / 1024**3, 2),

        "used": round(disk.used / 1024**3, 2),

        "free": round(disk.free / 1024**3, 2),

        "percent": round(disk.percent, 1)

    }


# ==========================
# Time
# ==========================

def get_time():

    return datetime.now().strftime("%H:%M:%S")


# ==========================
# Date
# ==========================

def get_date():

    return datetime.now().strftime("%d.%m.%Y")


# ==========================
# System
# ==========================

def get_system():

    return {

        "system": platform.system(),

        "release": platform.release(),

        "version": platform.version(),

        "machine": platform.machine(),

        "processor": platform.processor()

    }


# ==========================
# Hostname
# ==========================

def get_hostname():

    return socket.gethostname()


# ==========================
# Local IP
# ==========================

def get_local_ip():

    return socket.gethostbyname(
        socket.gethostname()
    )


# ==========================
# Battery
# ==========================

def get_battery():

    battery = psutil.sensors_battery()

    if battery is None:

        return None

    return {

        "percent": battery.percent,

        "charging": battery.power_plugged

    }


# ==========================
# Processes
# ==========================

def get_processes(limit=20):

    processes = []

    for p in psutil.process_iter(["name"]):

        try:

            processes.append(
                p.info["name"]
            )

        except:

            pass

    return processes[:limit]