import os
import shutil


# ==========================
# Показать файлы
# ==========================

def list_files(path="."):

    try:
        return os.listdir(path)

    except Exception as e:
        return f"Ошибка: {e}"


# ==========================
# Найти файл
# ==========================

def find_file(name, path="."):

    result = []

    for root, dirs, files in os.walk(path):

        for file in files:

            if name.lower() in file.lower():

                result.append(
                    os.path.join(root, file)
                )

    return result


# ==========================
# Прочитать файл
# ==========================

def read_file(path):

    try:

        with open(path, "r", encoding="utf-8") as f:

            return f.read()

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Создать файл
# ==========================

def create_file(path, content=""):

    try:

        with open(path, "w", encoding="utf-8") as f:

            f.write(content)

        return f"Файл {path} создан."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Записать в файл
# ==========================

def write_file(path, content):

    try:

        with open(path, "w", encoding="utf-8") as f:

            f.write(content)

        return "Записано."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Добавить в файл
# ==========================

def append_file(path, content):

    try:

        with open(path, "a", encoding="utf-8") as f:

            f.write(content)

        return "Добавлено."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Удалить файл
# ==========================

def delete_file(path):

    try:

        os.remove(path)

        return "Файл удалён."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Переименовать
# ==========================

def rename_file(old, new):

    try:

        os.rename(old, new)

        return "Файл переименован."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Копировать
# ==========================

def copy_file(src, dst):

    try:

        shutil.copy2(src, dst)

        return "Файл скопирован."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Переместить
# ==========================

def move_file(src, dst):

    try:

        shutil.move(src, dst)

        return "Файл перемещён."

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Размер файла
# ==========================

def file_size(path):

    try:

        size = os.path.getsize(path)

        return round(size / 1024, 2)

    except Exception as e:

        return f"Ошибка: {e}"


# ==========================
# Существует ли файл
# ==========================

def exists(path):

    return os.path.exists(path)