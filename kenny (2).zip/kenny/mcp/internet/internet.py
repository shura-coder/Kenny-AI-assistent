from config import TAVILY_API_KEY

from mcp.internet.providers import (
    DummyProvider,
    TavilyProvider
)

import requests


if TAVILY_API_KEY:

    provider = TavilyProvider(TAVILY_API_KEY)

else:

    provider = DummyProvider()


def search(query):

    return provider.search(query)


def get_page(url):

    response = requests.get(

        url,

        timeout=20

    )

    response.raise_for_status()

    return response.text[:5000]


def is_online():

    try:

        requests.get(

            "https://google.com",

            timeout=5

        )

        return True

    except:

        return False