import requests


class InternetProvider:

    def search(self, query):

        raise NotImplementedError


class DummyProvider(InternetProvider):

    def search(self, query):

        return (
            "Поиск пока не настроен.\n"
            f"Запрос: {query}"
        )


class TavilyProvider(InternetProvider):

    def __init__(self, api_key):

        self.api_key = api_key

    def search(self, query):

        response = requests.post(

            "https://api.tavily.com/search",

            json={

                "api_key": self.api_key,

                "query": query,

                "max_results": 5

            },

            timeout=30

        )

        response.raise_for_status()

        data = response.json()

        result = ""

        for item in data["results"]:

            result += f"{item['title']}\n"
            result += f"{item['url']}\n"
            result += f"{item['content']}\n\n"

        return result