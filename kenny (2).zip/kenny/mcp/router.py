from tool_registry import get


def execute(tool, *args):

    func = get(tool)

    if func is None:

        return f"Инструмент '{tool}' не найден."

    try:

        return func(*args)

    except Exception as e:

        return f"Ошибка выполнения {tool}: {e}"