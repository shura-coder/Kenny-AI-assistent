from mcp.router import execute


def run_tool(tool, *args):
    return execute(tool, *args)